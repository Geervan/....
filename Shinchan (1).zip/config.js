module.exports = {
    //CHANGE ALL OF THESE
  prefix : "!",
    token: "Nzc2NzA4Njc0NDc5MTk0MTI0.X640Ug.f3XqkBMnsLlpna-OKe-X71IrML0",
    botname: "Shinchan",
   creator : "Harry Potter #1587",
   tenorkey: "	WTTB9777EF8L",
   
    // API AUTHORIZATION
    authorization: "NzY1NDEzMzE4ODI2NTI0Njgy.MTYyNTIyMjAwNTI0OA==.2bdb8b94bb3e299c26baada7a995bb97"

}
